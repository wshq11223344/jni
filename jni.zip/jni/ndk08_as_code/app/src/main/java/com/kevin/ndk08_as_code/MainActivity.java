package com.kevin.ndk08_as_code;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private final static String TAG = MainActivity.class.getSimpleName();

    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        test01();
    }

    public native String stringFromJNI();

    public native void test01();

    public native void addTest01(int number, String text, int[] intArray, String[] array);

    public native void putStudent(Student student);

    public void test01(View view) {
        int[] ints = {1, 3, 4, 5, 6};
        String[] strings = {"李小龙", "李连杰"};
        addTest01(9527, "李元霸", ints, strings);

        for (int anInt : ints) {
            Log.d(TAG, "test01: " + anInt);
        }

        for (int i = 0; i < strings.length; i++) {
            Log.d(TAG, "test01: " + strings[i]);
        }

    }


    public void test02(View view) {
        Student student = new Student();
        student.age = 98;
        student.name = "雄霸";

        putStudent(student);
    }
}
