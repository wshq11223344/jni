package com.kevin.ndk08_as_code;

public class Person {

    public void setStudent(Student student) {

    }
}
