#include <jni.h>
#include <string>
#include <android/log.h>
#include "mylog.h"
//#include <cstdint>
//extern "C" {
//#include <stdint.h>
//}




using namespace std;

extern "C" JNIEXPORT jstring JNICALL
Java_com_kevin_ndk08_1as_1code_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

extern "C" // 支持C语言的代码
JNIEXPORT // Linux 和 Windows jni.h 内部定义全部都不一样，此宏代表我要暴露出去的标准形式定义
// 例如：在Windows中，对外暴露的标准就规定了，所以函数必须是Windows系统规则定义的

void JNICALL // Linux 和 Windows jni.h 内部定义全部都不一样，此宏代表 当前函数 压栈规则（形参规则）
// 例如：Windows中：代表函数压栈 从右 到 左边
Java_com_kevin_ndk08_1as_1code_MainActivity_test01(JNIEnv *env, jobject thiz) {
    LOGD("test01\n");
}

extern "C"
JNIEXPORT
void JNICALL
Java_com_kevin_ndk08_1as_1code_MainActivity_addTest01(
        JNIEnv *env,  // Java虚拟机 自动携带过来的，就是为了 让我们可以使用JNI的API
        jobject thiz, // java中的 MainActivity 这个对象
        jint number,
        jstring text,
        jintArray int_array,
        jobjectArray string_array) {
    // C领域中         JNI领域中          Java领域中
    // int              jint            int
    // const char *    jstring          String

    int my_number = number;
    LOGD("my_number: %d\n", my_number);

    // 参数二：第一重意思：是否在内部完成Copy操作，NULL==0 false，  第二重意思：要给他一个值，让内部可以转起来，这个值，随意
    const char *my_text = env->GetStringUTFChars(text, NULL);
    LOGD("my_text: %s\n", my_text);
    // 回收 GetStringUTFChars
    env->ReleaseStringUTFChars(text, my_text);

    // 打印Int数组
    jint *my_int_array = env->GetIntArrayElements(int_array, NULL);
    jsize intsize = env->GetArrayLength(int_array);

    for (int i = 0; i < intsize; ++i) {
        int result = *(my_int_array + i);
        *(my_int_array + i) += 1000;
        LOGD("遍历IntArray里面的值：%d\n", result);
    }
    // 回收
    env->ReleaseIntArrayElements(int_array, my_int_array, 0); // 0代表要刷新

    // 打印String数组
    jsize jsize1 = env->GetArrayLength(string_array);

    for (int i = 0; i < jsize1; ++i) {
        jobject jobject1 = env->GetObjectArrayElement(string_array, i);
        jstring jstring1 = static_cast<jstring >(jobject1);
        const char *itemStr = env->GetStringUTFChars(jstring1, NULL);
        LOGD("遍历String Array 里面的值：%s\n", itemStr);
    }

}

extern "C"
JNIEXPORT void JNICALL
Java_com_kevin_ndk08_1as_1code_MainActivity_putStudent(JNIEnv *env,
                                                       jobject thiz,
                                                       jobject student) {

    // C领域中         JNI领域中          Java领域中
    //                jclass            class
    //                jmethodID         Method

    // 1.获取字节码
    const char *student_clss_str = "com/kevin/ndk08_as_code/Student";
    jclass student_class = env->FindClass(student_clss_str);

    // 2.拿到方法对象
    const char *sig = "(Ljava/lang/String;)V"; // 方法签名  javap -s 全类名 必须在.class下
//    jmethodID setName = env->GetMethodID(student_class, "setName", sig);
    jmethodID setName = env->GetMethodID(student_class, "setName", "(Ljava/lang/String;)V");

    sig = "(I)V";
    jmethodID setAge = env->GetMethodID(student_class, "setAge", sig);

    sig = "()V";
    jmethodID myStaticMethod = env->GetStaticMethodID(student_class, "myStaticMethod", sig);

    sig = "()I";
    jmethodID getAge = env->GetMethodID(student_class, "getAge", "()I");

    jmethodID valueStaticMethod = env->GetStaticMethodID(student_class, "valueStaticMethod", "()I");

    jfieldID jfieldId = env->GetFieldID(student_class, "name", "Ljava/lang/String;");
    env->SetObjectField(student, jfieldId, env->NewStringUTF("66666"));
    jobject jobject1 = env->GetObjectField(student, jfieldId);
    jstring jstring1 = static_cast<jstring >(jobject1);
    const char *string1 = env->GetStringUTFChars(jstring1, NULL);
    LOGD("Java value:%s\n", string1);

    jfieldID jfieldId1 = env->GetStaticFieldID(student_class, "TAG", "Ljava/lang/String;");
    jobject jobject2 = env->GetStaticObjectField(student_class, jfieldId1);
    jstring jstring2 = static_cast<jstring >(jobject2);
    const char *string2 = env->GetStringUTFChars(jstring2, NULL);
    LOGD("Java value:%s\n", string2);

    // 3.调用对象
    const char *str = "AAAAAAAA";
    jstring str2 = env->NewStringUTF(str);
    env->CallVoidMethod(student, setName, str2);
    env->CallVoidMethod(student, setAge, 888);
    env->CallStaticVoidMethod(student_class, myStaticMethod);
    jint age = env->CallIntMethod(student, getAge);
    LOGD("Java getAge:%d\n", age);
    jint value = env->CallStaticIntMethod(student_class, valueStaticMethod);
    LOGD("Java value:%d\n", value);
    env->DeleteLocalRef(student_class); // 回收
    env->DeleteLocalRef(student); // 回收
}