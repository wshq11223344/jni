//
// Created by qiqi on 2020/8/25.
//

#ifndef NDK08_AS_CODE_LOG_H
#define NDK08_AS_CODE_LOG_H

#endif //NDK08_AS_CODE_LOG_H

#include <android/log.h>

// 日志打印
#define TAG "qiqi"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)

