#include <jni.h>
#include <string>
#include <android/log.h>
#include <pthread.h>

extern "C" JNIEXPORT jstring JNICALL
Java_com_kevin_ndk09_1code_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

// TODO 对象的深入
extern "C"
JNIEXPORT void JNICALL
Java_com_kevin_ndk09_1code_MainActivity_testObject(JNIEnv *env, jobject thiz) {
    // TODO: implement testObject()

    const char *person_class_str = "com/kevin/ndk09_code/Person";
    jclass person_class = env->FindClass(person_class_str);
    jobject person = env->AllocObject(person_class);

    // 初始化方法
    const char *sig = "(Lcom/kevin/ndk09_code/Student;)V";
    jmethodID setStudent = env->GetMethodID(person_class, "setStudent", sig);

    // 直接创建 Student 对象
    const char *student_class_str = "com/kevin/ndk09_code/Student";
    jclass student_class = env->FindClass(student_class_str);
    jobject student = env->AllocObject(student_class);

    // 给我们创建出来的Student对象赋值
    sig = "(Ljava/lang/String;)V";
    jmethodID setName = env->GetMethodID(student_class, "setName", sig);
    jstring value = env->NewStringUTF("刘德华");
    env->CallVoidMethod(student, setName, value);

    sig = "(I)V";
    jmethodID setAge = env->GetMethodID(student_class, "setAge", sig);
    env->CallVoidMethod(student, setAge, 89);

    // 调用Person里面的方法
    env->CallVoidMethod(person, setStudent, student);

    // 回收方式
    env->DeleteLocalRef(student_class); // jclass  jobject
    env->DeleteLocalRef(student);
    env->DeleteLocalRef(person_class);
    env->DeleteLocalRef(person);
}

// TODO 引用类型 + Java构造方法的实例化

jclass dogClass;

extern "C"
JNIEXPORT void JNICALL
Java_com_kevin_ndk09_1code_MainActivity_testDog(JNIEnv *env, jobject thiz) {
    // 局部引用：如果在函数里面，是在栈区，不用回收，函数结束，会自动回收 ，为了专业性，最好要写回收

    if (dogClass == NULL) {
        // 第一次满足，  第二次不满足了
        // 局部引用的方式
        /*const char * dog_class_str = "com/kevin/ndk09_code/Dog";
        dogClass = env->FindClass(dog_class_str);*/

        // 解决各个局部引用带来的问题，全局引用（自己来提升）
        const char *dog_class_str = "com/kevin/ndk09_code/Dog";
        jclass temp = env->FindClass(dog_class_str);
        dogClass = static_cast<jclass>(env->NewGlobalRef(temp));

        // 手动释放全局引用之后，再次点击，没有进来
        __android_log_print(ANDROID_LOG_DEBUG, "Kevin", "dogClass == NULL");
    }

    // Java构造方法的实例化
    const char *sig = "()V";
    const char *method = "<init>"; // Java构造方法的标识
    jmethodID init = env->GetMethodID(dogClass, method, sig);
    jobject dog = env->NewObject(dogClass, init); // 由于dogClass 是悬空的，直接报错

    // 会隐式释放 dogClass  ， dogClass不为NULL， 悬空   同时手动全局释放一致
}

// 此函数就是为了手动释放全局
extern "C"
JNIEXPORT void JNICALL
Java_com_kevin_ndk09_1code_MainActivity_testUnDog(JNIEnv *env, jobject thiz) {
    // TODO: implement testUnDog()
    if (dogClass != NULL) {
        __android_log_print(ANDROID_LOG_DEBUG, "Kevin", "全局应用被释放了，上面的按钮不能点击了，否则报错");
        env->DeleteGlobalRef(dogClass);
        dogClass = NULL;
    }

    // Studnet * student = new Student; // 堆 必须释放
}

// TODO 下面开始动态注册

// 现在是静态注册
extern "C"
JNIEXPORT void JNICALL
Java_com_kevin_ndk09_1code_MainActivity_staticReg(JNIEnv *env, jobject instance) {

}

// 下面是动态注册
JavaVM *jvm;

void register01(JNIEnv *env, jobject instance, jstring text) {
    const char *textValue = env->GetStringUTFChars(text, NULL);
    __android_log_print(ANDROID_LOG_DEBUG, "Kevin", "动态注册的函数执行了 %s", textValue);
    env->ReleaseStringUTFChars(text, textValue);
}

int register02(JNIEnv *env, jobject instance, jstring text) {
    const char *textValue = env->GetStringUTFChars(text, NULL);
    __android_log_print(ANDROID_LOG_DEBUG, "Kevin", "动态注册的函数执行了 %s", textValue);
    env->ReleaseStringUTFChars(text, textValue);
}

/*
 * typedef struct {
    const char* name;
    const char* signature;
    void*       fnPtr;
    } JNINativeMethod;
 */
static const JNINativeMethod jniNativeMethod[] = {
        {"registerJava01", "(Ljava/lang/String;)V", (void *) (register01)},
        {"registerJava02", "(Ljava/lang/String;)V", (int *) (register02)}
};

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *javaVm, void *pVoid) {
    jvm = javaVm;

    // 通过虚拟机 创建全新的 evn
    JNIEnv *jniEnv = nullptr;
    jint result = javaVm->GetEnv(reinterpret_cast<void **>(&jniEnv), JNI_VERSION_1_6);
    // 参数2：是JNI的版本 NDK 1.6   JavaJni 1.8
    if (result != JNI_OK) {
        return -1; // 主动报错
    }

    const char *mainActivityClassStr = "com/kevin/ndk09_code/MainActivity";
    jclass mainActivityClass = jniEnv->FindClass(mainActivityClassStr);

    jniEnv->RegisterNatives(mainActivityClass, jniNativeMethod,
                            sizeof(jniNativeMethod) / sizeof(JNINativeMethod)); // 参数三：到底要动态注册几个

    return JNI_VERSION_1_6;
}

// TODO JNI 线程示例

jobject instance;

void *customThread(void *pVoid) {
    /*for (int i = 0; i <30; ++i) {
        __android_log_print(ANDROID_LOG_DEBUG, "Kevin", "%d:", i);
    }*/

    // jobject instance = static_cast<jobject>(pVoid);

    // 悬空 == instance

    // 调用的话，一定需要JNIEnv *env
    // JNIEnv *env 无法跨越线程，只有JavaVM才能跨越线程

    JNIEnv *env = nullptr; // 全新的env
    int result = jvm->AttachCurrentThread(&env, 0); // 把native的线程，附加到JVM
    if (result != 0) {
        return 0;
    }
    // MainActivity main = AllocaObject(); // C++实例化MainActivity，无法拿到MainActivity上下文

    // 包名 + 类名
    /*const char * mainActivityStr = "com/kevin/ndk09_code/MainActivity";
    jclass mainActivityClass = env->FindClass(mainActivityStr);*/
    jclass mainActivityClass = env->GetObjectClass(instance);

    // 拿到MainActivity的updateUI
    const char *sig = "()V";
    jmethodID updateUI = env->GetMethodID(mainActivityClass, "updateUI", sig);

    env->CallVoidMethod(instance, updateUI);

    // 解除 附加 到 JVM 的native线程
    jvm->DetachCurrentThread();

    return 0;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_kevin_ndk09_1code_MainActivity_testThread(JNIEnv *env, jobject thiz) {
    instance = env->NewGlobalRef(thiz); // 全局的，就不会被释放，所以可以在线程里面用

    // 如果是非全局的，函数一结束，就被释放了
    pthread_t pthreadID;
    pthread_create(&pthreadID, 0, customThread, 0);
    pthread_join(pthreadID, 0);
}

// 释放全局引用
extern "C"
JNIEXPORT void JNICALL
Java_com_kevin_ndk09_1code_MainActivity_unThread(JNIEnv *env, jobject thiz) {
    if (NULL != instance) {
        env->DeleteGlobalRef(instance);
        instance = NULL;
    }
}
