package com.kevin.ndk09_code;

import android.util.Log;

public class Person {

    private static final String TAG = Person.class.getSimpleName();

    public void setStudent(Student student) {
        Log.d(TAG, "setStudent: " + student.toString());
    }

}
