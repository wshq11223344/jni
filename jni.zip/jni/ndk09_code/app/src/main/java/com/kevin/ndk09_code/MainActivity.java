package com.kevin.ndk09_code;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public native String stringFromJNI();
    public native void testObject();
    public native void testDog();
    public native void testUnDog();
    public native void staticReg();

    // 动态注册的函数
    public native void registerJava01(String text);
    public native void registerJava02(String text);

    public native void testThread();
    public native void unThread();

    public void test01(View view) {
        testObject();
    }

    public void test02(View view) {
        testDog();
    }

    public void test03(View view) {
        testUnDog();
    }

    public void test04(View view) {
        registerJava01("李AAAAAAAAAAAAAA");
    }

    public void test05(View view) {
        testThread();
    }

    // AndroidUI操作，让C++线程里面来调用
    public void updateUI() {
        if (Looper.getMainLooper() == Looper.myLooper()) {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("UI")
                    .setMessage("updateUI run ...")
                    .setPositiveButton("老夫知道了", null)
                    .show();
        } else {
            Log.d("MainActivity", "updateUI: 所属与子线程.......只能打印日志了");
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("UI")
                            .setMessage("updateUI run ...")
                            .setPositiveButton("老夫知道了", null)
                            .show();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unThread();
    }
}
