package com.kevin.ndk09_code;

import android.util.Log;

public class Dog {

    public Dog() {
        Log.d("Dog", "Dog: 构造方法被C++中直接实例化了....");
    }

}
